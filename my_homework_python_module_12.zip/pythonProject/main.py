per_cent = {'ТКБ': 5.6, 'СКБ': 5.9, 'ВТБ': 4.28, 'СБЕР': 4.0}

money = float(input("Введите сумму: "))

tkb = money / 100 * per_cent["ТКБ"]
tkb_deposit = tkb + money

skb = money / 100 * per_cent["СКБ"]
skb_deposit = skb + money

vtb = money / 100 * per_cent["ВТБ"]
vtb_deposit = vtb + money

sber = money / 100 * per_cent["СБЕР"]
sber_deposit = sber + money

deposit_spiskom = [tkb_deposit,skb_deposit,vtb_deposit,sber_deposit]
max_value = max(deposit_spiskom)

deposit = ["ТКБ: "+"%.2f" % (tkb_deposit),"СКБ: "+"%.2f" % (skb_deposit),"ВТБ: "+"%.2f" % (vtb_deposit),"СБЕР: "+"%.2f" % (sber_deposit)]


print("Накопленная сумма за год, будет равна :", deposit)
print("Максимальная сумма, которую вы можете заработать - ",round(max_value,2))

